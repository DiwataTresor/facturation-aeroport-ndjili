export const INPUT="border border-gray-200 rounded-md py-2 min-w-[200px]  px-3 outline-none ml-3"; 
export const BTN="bg-blue-400 hover:bg-blue-700 text-white rounded-sm py-2 min-w-[150px]  px-3 outline-none ml-3"; 
export const BTNRESET="bg-transparent border border-gray-800 hover:bg-gray-100 text-gray-800 rounded-sm py-2 min-w-[150px]  px-3 outline-none ml-3"; 
// import React from 'react'

// const index = () => {
//   return (
//     <div className=''>index</div>
//   )
// }

// export default index