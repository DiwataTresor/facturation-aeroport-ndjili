import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./../pages/Dashboard";
import Encaissement from "./../pages/Encaissement";
import Encaissementmanuel from "./../pages/Encaissementmanuel";
import Entreevehicule from "./../pages/Entreevehicule";
import Sortievehicule from "./../pages/Sortievehicule";
import Ticketoffline from "./../pages/Ticketoffline";
import RapportEncaissementParJour from "./../pages/RapportEncaissementParJour";
import Vehiculestationne from "./../pages/Vehiculestationne";
import Tarif from "./../pages/Tarif";
import Recherche from "./../pages/Recherche";
import Rapportglobal from "./../pages/Rapportglobal";
import RapportglobalDetail from "./../pages/RapportglobalDetail";
import Recettecaissier from "./../pages/Recettecaissier";
import Utilisateur from "./../pages/Utilisateur";
import Reinit from "./../pages/Reinit";
import Mouvements from "./../pages/Mouvements";
import Taux from "./../pages/Taux";
import Journal from "./../pages/Journal";
import EncaissementScanner from "./../pages/EncaissementScanner";



const Wrapper = () => {
  useEffect(() => {}, []);
  return (
      <div className="p-4">
        
      </div>
  );
};

export default Wrapper;
