import React from 'react'

function Recherche() {
  return (
    <div>Recherche 22</div>
  )
}

export default Recherche