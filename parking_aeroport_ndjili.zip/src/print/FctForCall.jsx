import React, { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';
import { ComponentToPrint}  from './ComponentToPrint';
 export const CallPrint = ()=>{
    
 };
